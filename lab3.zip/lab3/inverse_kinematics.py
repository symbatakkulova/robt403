import numpy as np

def inverse_kinematics(x, y, phi):
    L1, L2, L3 = 1, 1, 1
    xw = x - L3*np.cos(phi)
    yw = y - L3*np.sin(phi)

    D = (xw**2 + yw**2 - L1**2 - L2**2) / (2*L1*L2)
    if abs(D) > 1:
        print("Unreachable position")
        return None

    q2 = np.arctan2(np.sqrt(1-D**2), D)
    q1 = np.arctan2(yw, xw) - np.arctan2(L2*np.sin(q2), L1 + L2*np.cos(q2))
    q3 = phi - q1 - q2
    return q1, q2, q3

# Example target
q = inverse_kinematics(0, 0, np.deg2rad(30))
if q:
    print("q1=%.2f°, q2=%.2f°, q3=%.2f°" % tuple(np.rad2deg(q)))
