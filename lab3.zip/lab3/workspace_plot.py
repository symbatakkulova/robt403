#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

# Link lengths
L1 = 2.0   # Link 1 (base to joint 1)
L2 = 2.0   # Link 2 (joint 1 to joint 2)
L3 = 1.5  # Link 3 (joint 2 to end effector)

# Joint angle ranges
q1_range = np.deg2rad(np.linspace(-80, 80, 100))  # Vary q1 (base joint)
q2_range = np.deg2rad(np.linspace(-60, 60, 100))  # Vary q2 (middle joint)
q3_range = np.deg2rad(np.linspace(-110, 110, 100))  # Vary q3 (end joint)

# Compute the end-effector positions
X, Y = [], []  # Lists to store the x and y positions of the end effector

# Loop over joint angles to calculate all possible end effector positions
for q1 in q1_range:
    for q2 in q2_range:
        for q3 in q3_range:
            # Calculate the positions of each joint
            x1 = L1 * np.cos(q1)
            y1 = L1 * np.sin(q1)

            x2 = x1 + L2 * np.cos(q1 + q2)
            y2 = y1 + L2 * np.sin(q1 + q2)

            x3 = x2 + L3 * np.cos(q1 + q2 + q3)
            y3 = y2 + L3 * np.sin(q1 + q2 + q3)

            # Store the end effector's (x3, y3) position for plotting
            X.append(x3)
            Y.append(y3)

            
# Plot the full workspace (all possible end-effector positions)



plt.figure(figsize=(6,6))
plt.scatter(X, Y, s=1.5, color='royalblue', label='End-Effector Reachable Positions')
plt.title('Full 3-DOF Workspace with Links and Joints')
plt.xlabel('X Position [m]')
plt.ylabel('Y Position [m]')
plt.axis('equal')
plt.grid(True)
plt.legend()
plt.show()

