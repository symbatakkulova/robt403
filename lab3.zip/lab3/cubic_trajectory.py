import numpy as np
import matplotlib.pyplot as plt

def cubic_coeff(q0, qf, v0, vf, tf):
    a0 = q0
    a1 = v0
    a2 = (3*(qf - q0)/tf**2) - (2*v0 + vf)/tf
    a3 = (2*(q0 - qf)/tf**3) + (v0 + vf)/tf**2
    return [a0, a1, a2, a3]

tf = 4
q0 = np.deg2rad([0, 0, 30])   # example initial positions
qf = np.deg2rad([15, -20, 15])  # example final positions
v0 = [0, 0, 0]
vf = [0, 0, 0]

t = np.linspace(0, tf, 200)
Q = np.zeros((3, len(t)))

for i in range(3):
    a0, a1, a2, a3 = cubic_coeff(q0[i], qf[i], v0[i], vf[i], tf)
    Q[i,:] = a0 + a1*t + a2*t**2 + a3*t**3

plt.plot(t, np.rad2deg(Q[0,:]), label='q1')
plt.plot(t, np.rad2deg(Q[1,:]), label='q2')
plt.plot(t, np.rad2deg(Q[2,:]), label='q3')
plt.legend()
plt.xlabel('Time [s]')
plt.ylabel('Joint angle [deg]')
plt.title('Cubic Joint Trajectories')
plt.show()
