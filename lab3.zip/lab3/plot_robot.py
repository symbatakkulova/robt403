import numpy as np
import matplotlib.pyplot as plt

def plot_robot(q1, q2, q3):
    L1, L2, L3 = 1, 1, 1
    p0 = np.array([0,0])
    p1 = np.array([L1*np.cos(q1), L1*np.sin(q1)])
    p2 = p1 + [L2*np.cos(q1+q2), L2*np.sin(q1+q2)]
    p3 = p2 + [L3*np.cos(q1+q2+q3), L3*np.sin(q1+q2+q3)]

    plt.plot([p0[0],p1[0]],[p0[1],p1[1]],'r-o')
    plt.plot([p1[0],p2[0]],[p1[1],p2[1]],'g-o')
    plt.plot([p2[0],p3[0]],[p2[1],p3[1]],'b-o')
    plt.axis('equal')
    plt.xlim(0, 4)
    plt.ylim(-0.1, 0.4)
    plt.title('Manipulator Configuration')
    plt.show()

plot_robot(np.deg2rad(-45), np.deg2rad(90), np.deg2rad(-45))
