#!/usr/bin/env python
import rospy
from std_msgs.msg import Float64
import time

class StepPublisher(object):
    def __init__(self):
        self.command_topic = rospy.get_param('~command_topic', '/joint1_position_controller/command')
        self.desired_topic = rospy.get_param('~desired_topic', '/joint1_desired')
        self.amplitude = float(rospy.get_param('~amplitude', 0.5))
        self.offset = float(rospy.get_param('~offset', 0.0))
        self.period = float(rospy.get_param('~period', 4.0))
        self.duty = float(rospy.get_param('~duty_cycle', 0.5))
        self.rate_hz = float(rospy.get_param('~rate', 50.0))
        self.duration = float(rospy.get_param('~duration', 0.0))

        self.pub_cmd = rospy.Publisher(self.command_topic, Float64, queue_size=10)
        self.pub_des = rospy.Publisher(self.desired_topic, Float64, queue_size=10)

        rospy.loginfo('StepPublisher -> %s (desired %s) amplitude=%.3f period=%.3f', self.command_topic, self.desired_topic, self.amplitude, self.period)

    def run(self):
        rate = rospy.Rate(self.rate_hz)
        start = time.time()
        while not rospy.is_shutdown():
            t = time.time() - start
            phase = (t % self.period) / self.period
            value = self.offset + (self.amplitude if phase < self.duty else 0.0)
            msg = Float64(data=value)
            self.pub_cmd.publish(msg)
            self.pub_des.publish(msg)
            rate.sleep()
            if self.duration > 0 and (t > self.duration):
                rospy.loginfo('StepPublisher duration reached, exiting')
                break

if __name__ == '__main__':
    rospy.init_node('step_publisher')
    node = StepPublisher()
    node.run()
