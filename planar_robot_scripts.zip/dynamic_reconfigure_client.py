#!/usr/bin/env python
import rospy
from dynamic_reconfigure.client import Client

if __name__ == '__main__':
    rospy.init_node('dynamic_reconfigure_client')
    server = rospy.get_param('~server_name', '/robot/joint1/PID')
    param = rospy.get_param('~param_name', 'P')
    try:
        value = float(rospy.get_param('~value'))
    except Exception:
        rospy.logerr('Parameter ~value must be provided and convertible to float')
        raise SystemExit(1)

    rospy.loginfo('Connecting to dynamic_reconfigure server: %s', server)
    try:
        client = Client(server, timeout=5.0)
    except Exception as e:
        rospy.logerr('Failed to connect to %s: %s', server, e)
        raise

    try:
        cfg = client.get_configuration()
    except Exception as e:
        rospy.logerr('Failed to get configuration from %s: %s', server, e)
        raise

    rospy.loginfo('Available params: %s', ','.join(sorted(cfg.keys())))
    if param not in cfg:
        rospy.logwarn('Requested param "%s" not in server config', param)
    else:
        rospy.loginfo('Setting %s = %s on %s', param, value, server)
        try:
            client.update_configuration({param: value})
            rospy.loginfo('Update sent')
        except Exception as e:
            rospy.logerr('Failed to update configuration: %s', e)
    rospy.loginfo('dynamic_reconfigure_client finished')
