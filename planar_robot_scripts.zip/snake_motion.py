#!/usr/bin/env python
import rospy
from std_msgs.msg import Float64
import math
import time
import ast

class SnakeMotion(object):
    def __init__(self):
        jt_param = rospy.get_param('~joint_topics', "['/joint1_position_controller/command','/joint2_position_controller/command']")
        if isinstance(jt_param, str):
            try:
                self.joint_topics = ast.literal_eval(jt_param)
            except Exception:
                self.joint_topics = [jt_param]
        else:
            self.joint_topics = list(jt_param)

        self.amplitude = float(rospy.get_param('~amplitude', 0.3))
        self.freq = float(rospy.get_param('~freq', 0.2))
        self.phase_shift = float(rospy.get_param('~phase_shift', 0.5))
        self.rate_hz = float(rospy.get_param('~rate', 50.0))

        self.publishers = [rospy.Publisher(t, Float64, queue_size=1) for t in self.joint_topics]
        rospy.loginfo('SnakeMotion -> joints: %s', ','.join(self.joint_topics))

    def run(self):
        rate = rospy.Rate(self.rate_hz)
        start = time.time()
        while not rospy.is_shutdown():
            t = time.time() - start
            base = 2.0 * math.pi * self.freq * t
            for i, pub in enumerate(self.publishers):
                phase = base + i * self.phase_shift
                val = self.amplitude * math.sin(phase)
                pub.publish(Float64(data=val))
            rate.sleep()

if __name__ == '__main__':
    rospy.init_node('snake_motion')
    node = SnakeMotion()
    node.run()
