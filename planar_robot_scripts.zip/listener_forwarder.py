#!/usr/bin/env python
import rospy
from std_msgs.msg import Float64

class ListenerForwarder(object):
    def __init__(self):
        listen_topic = rospy.get_param('~listen_topic', '/input_float')
        self.command_topic = rospy.get_param('~command_topic', '/joint1_position_controller/command')
        self.prev = None

        self.pub = rospy.Publisher(self.command_topic, Float64, queue_size=10)
        self.sub = rospy.Subscriber(listen_topic, Float64, self.cb)
        rospy.loginfo('ListenerForwarder: listening %s, publishing to %s', listen_topic, self.command_topic)

    def cb(self, msg):
        try:
            val = float(msg.data)
        except Exception as e:
            rospy.logwarn('Received non-float: %s', str(e))
            return

        if (self.prev is None) or (val > self.prev):
            out = Float64()
            out.data = val
            self.pub.publish(out)
            rospy.loginfo('Forwarded value %.6f -> %s', val, self.command_topic)
        else:
            rospy.loginfo('Ignored value %.6f (prev %.6f) — not greater', val, self.prev if self.prev is not None else float('nan'))

        self.prev = val

if __name__ == '__main__':
    rospy.init_node('listener_forwarder')
    ListenerForwarder()
    rospy.spin()
