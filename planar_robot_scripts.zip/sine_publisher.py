#!/usr/bin/env python
import rospy
from std_msgs.msg import Float64
import math
import time

class SinePublisher(object):
    def __init__(self):
        self.command_topic = rospy.get_param('~command_topic', '/joint2_position_controller/command')
        self.desired_topic = rospy.get_param('~desired_topic', '/joint2_desired')
        self.amplitude = float(rospy.get_param('~amplitude', 0.4))
        self.freq = float(rospy.get_param('~freq', 0.2))
        self.offset = float(rospy.get_param('~offset', 0.0))
        self.rate_hz = float(rospy.get_param('~rate', 50.0))
        self.duration = float(rospy.get_param('~duration', 0.0))

        self.pub_cmd = rospy.Publisher(self.command_topic, Float64, queue_size=10)
        self.pub_des = rospy.Publisher(self.desired_topic, Float64, queue_size=10)

        rospy.loginfo('SinePublisher -> %s (desired %s) amp=%.3f freq=%.3f', self.command_topic, self.desired_topic, self.amplitude, self.freq)

    def run(self):
        rate = rospy.Rate(self.rate_hz)
        start = time.time()
        while not rospy.is_shutdown():
            t = time.time() - start
            value = self.offset + self.amplitude * math.sin(2.0 * math.pi * self.freq * t)
            msg = Float64(data=value)
            self.pub_cmd.publish(msg)
            self.pub_des.publish(msg)
            rate.sleep()
            if self.duration > 0 and (t > self.duration):
                rospy.loginfo('SinePublisher duration reached, exiting')
                break

if __name__ == '__main__':
    rospy.init_node('sine_publisher')
    node = SinePublisher()
    node.run()
